import streamlit as st
import json, os
from scraper.league_scraper import scrape_league_teams
from scraper.team_scraper import scrape_team_stats
from analysis.engine import analyze_match

st.set_page_config(layout="wide", page_title="⚽ Maç Analiz")

DATA_PATH = "data/teams.json"

def load_data():
    if not os.path.exists(DATA_PATH):
        return {}
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        c = f.read().strip()
        return json.loads(c) if c else {}

def render_result(res, t1, t2):
    st.markdown(
        f"<h1 style='text-align:center'>{t1} <b>{res['Skor']}</b> {t2}</h1>",
        unsafe_allow_html=True
    )

    st.progress(res["Confidence Skoru"] / 100)
    st.caption(f"🔒 Güven: {res['Confidence']} ({res['Confidence Skoru']}%)")

    if res["Oynanabilir"]:
        st.success("🔥 OYNANIR – Tek maç / ana kombine")
    else:
        st.warning("⚠ PAS / Riskli")

    st.divider()

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Maç Sonucu", res["MS"])
    c2.metric("Çifte Şans", res["Çifte Şans"])
    c3.metric("1.5 ÜST", "✔" if res["1.5 ÜST"] else "✖")
    c4.metric("2.5 ÜST", "✔" if res["2.5 ÜST"] else "✖")

    c5, c6, c7 = st.columns(3)
    c5.metric("3.5 ÜST", "✔" if res["3.5 ÜST"] else "✖")
    c6.metric("KG VAR", "✔" if res["KG VAR"] else "✖")
    c7.metric("Confidence", res["Confidence"])

st.sidebar.title("⚙ Menü")
page = st.sidebar.radio("Sayfa", ["Analiz", "Ayarlar"])

if page == "Ayarlar":
    st.title("Lig Ekle")
    name = st.text_input("Lig Adı")
    url = st.text_input("Lig URL (SofaScore)")
    if st.button("LİGİ EKLE"):
        with st.spinner("Takımlar çekiliyor..."):
            scrape_league_teams(url, name)
        st.success("Lig eklendi")

else:
    data = load_data()
    if not data:
        st.warning("Önce lig ekle")
        st.stop()

    league = st.selectbox("Lig", data.keys())
    teams = list(data[league].keys())

    t1 = st.selectbox("Ev Sahibi", teams)
    t2 = st.selectbox("Deplasman", teams)

    if st.button("ANALİZ ET"):
        with st.spinner("🔍 Maç analiz ediliyor..."):
            s1 = scrape_team_stats(data[league][t1])
            s2 = scrape_team_stats(data[league][t2])
            res = analyze_match(s1, s2)

        render_result(res, t1, t2)
