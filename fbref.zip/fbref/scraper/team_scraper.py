import time
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By


def scrape_team_stats(team_url):
    options = uc.ChromeOptions()
    options.add_argument("--headless=new")
    options.add_argument("--disable-blink-features=AutomationControlled")

    driver = uc.Chrome(options=options)
    driver.get(team_url + "#tab:statistics")
    time.sleep(6)

    stats = {
        "goals": 0.0,
        "shots": 0.0,
        "sot": 0.0,
        "assists": 0.0,
        "yellow": 0.0,
        "red": 0.0
    }

    try:
        rows = driver.find_elements(
            By.XPATH,
            "//div[contains(@class,'jc_space-between')]"
        )

        for row in rows:
            try:
                label = row.find_element(By.XPATH, ".//span[1]").text.lower()
                value = row.find_element(By.XPATH, ".//span[last()]").text

                value = value.replace(",", ".").replace("%", "").strip()
                if value == "":
                    continue

                val = float(value)

                if "gol" in label:
                    stats["goals"] = val
                elif "toplam şut" in label or "şut" in label:
                    stats["shots"] = val
                elif "isabetli" in label:
                    stats["sot"] = val
                elif "asist" in label:
                    stats["assists"] = val
                elif "sarı" in label:
                    stats["yellow"] = val
                elif "kırmızı" in label:
                    stats["red"] = val

            except:
                continue

    except:
        pass

    driver.quit()
    return stats
