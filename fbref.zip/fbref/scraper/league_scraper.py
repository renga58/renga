import time
import json
import os
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By


def scrape_league_teams(league_url, league_name):
    options = uc.ChromeOptions()
    options.add_argument("--headless=new")
    options.add_argument("--disable-blink-features=AutomationControlled")

    driver = uc.Chrome(options=options)
    driver.get(league_url)
    time.sleep(6)

    teams = {}

    links = driver.find_elements(
        By.XPATH, "//a[contains(@href,'/football/team/')]"
    )

    for a in links:
        try:
            href = a.get_attribute("href")
            name = a.find_element(By.XPATH, ".//span").text.strip()

            if name and href:
                if href.startswith("/"):
                    href = "https://www.sofascore.com" + href
                teams[name] = href
        except:
            continue

    driver.quit()

    os.makedirs("data", exist_ok=True)
    path = "data/teams.json"

    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            content = f.read().strip()
            data = json.loads(content) if content else {}
    else:
        data = {}

    data[league_name] = teams

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    return teams
