import math
from scipy.stats import poisson

def poisson_goal(xg, max_goals=7):
    probs = [poisson.pmf(i, xg) for i in range(max_goals)]
    return probs.index(max(probs))


def analyze_match(home, away):
    # ---------------- FORM (FALLBACK'LI) ----------------
    home_form_scored = home.get("form_scored", home.get("goals", 1))
    home_form_conceded = home.get("form_conceded", home.get("conceded", 1))

    away_form_scored = away.get("form_scored", away.get("goals", 1))
    away_form_conceded = away.get("form_conceded", away.get("conceded", 1))

    home_form = 1 + (home_form_scored - home_form_conceded) * 0.15
    away_form = 1 + (away_form_scored - away_form_conceded) * 0.15

    # ---------------- HÜCUM ----------------
    home_attack = (
        home.get("goals", 1) * 0.4 +
        home.get("shots", 5) * 0.2 +
        home.get("sot", 2) * 0.4
    )

    away_attack = (
        away.get("goals", 1) * 0.4 +
        away.get("shots", 5) * 0.2 +
        away.get("sot", 2) * 0.4
    )

    # ---------------- DEFANS ----------------
    home_def = 1 + home.get("conceded", 1) * 0.3 + home.get("yellow", 1) * 0.1
    away_def = 1 + away.get("conceded", 1) * 0.3 + away.get("yellow", 1) * 0.1

    # ---------------- TEMPO ----------------
    tempo = (home.get("shots", 5) + away.get("shots", 5)) / 20
    tempo = max(0.8, min(tempo, 1.5))

    # ---------------- xG (SINIRSIZ) ----------------
    home_xg = (home_attack / away_def) * home_form * tempo
    away_xg = (away_attack / home_def) * away_form * tempo

    # ---------------- SKOR ----------------
    home_goals = poisson_goal(home_xg)
    away_goals = poisson_goal(away_xg)
    total = home_goals + away_goals

    # ---------------- MS ----------------
    if home_goals > away_goals:
        ms = "MS 1"
        double = "1X"
    elif away_goals > home_goals:
        ms = "MS 2"
        double = "X2"
    else:
        ms = "MS X"
        double = "1X / X2"

    # ---------------- CONFIDENCE ----------------
    confidence_score = min(100, round((abs(home_xg - away_xg) + total) * 12))
    confidence = (
        "Yüksek" if confidence_score >= 70
        else "Orta" if confidence_score >= 45
        else "Düşük"
    )

    oynanir = confidence_score >= 70 and total >= 2

    return {
        "Skor": f"{home_goals} - {away_goals}",
        "MS": ms,
        "Çifte Şans": double,
        "1.5 ÜST": total >= 2,
        "2.5 ÜST": total >= 3,
        "3.5 ÜST": total >= 4,
        "KG VAR": home_goals > 0 and away_goals > 0,
        "Confidence": confidence,
        "Confidence Skoru": confidence_score,
        "Oynanabilir": oynanir
    }
